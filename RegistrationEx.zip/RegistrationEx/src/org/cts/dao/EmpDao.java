package org.cts.dao;

import org.cts.bean.Emp;

public interface EmpDao {
	public boolean insert(Emp e);
	
}
