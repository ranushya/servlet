package org.cts.services;

import org.cts.bean.Emp;

public interface EmpService {
	public boolean register(Emp e);
}
